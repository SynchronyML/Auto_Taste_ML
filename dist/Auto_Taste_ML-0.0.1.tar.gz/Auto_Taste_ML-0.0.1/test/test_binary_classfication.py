from auto_ml_c import binary_classfication
def test_cal_add_1():
    assert binary_classfication.cal_add_1(1,1) == 2